#include <stdint.h>

int32_t Ivy = 500;
int32_t Leo = -400;
int32_t Zoe = 300;
int32_t Ian = -200;
int32_t Joy = 0;

extern void asm_main(void);

int main(void)
{
    asm_main();
    while (1) {}
}
