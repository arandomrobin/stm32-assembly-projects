extern void asm_main(void);

int main(void)
{
    asm_main();
    while (1);
}
